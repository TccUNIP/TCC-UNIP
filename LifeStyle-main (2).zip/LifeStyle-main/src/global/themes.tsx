export const themas = {
    colors:{
        primary:'#fdf6ed',
        secondary:'#314948',
        fundoInput:"#c8d1c6",
        text: '#333333', 
        relax:"",
        relaxSecondary:"#ccffcc",
        blue: '#007bff'
        
        
    

    }
}