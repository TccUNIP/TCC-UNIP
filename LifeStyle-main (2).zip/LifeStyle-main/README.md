# Bibibliotecas 

```bash

npm install

npm install -g expo-cli

npm install @react-native-firebase/messaging

npm install axios

npm install react-native-reanimated

npm install react-native-vector-icons

npm install react-native-screens react-native-safe-area-context

npm install @react-navigation/bottom-tabs

npm install @react-navigation/stack

npm install @react-navigation/native

npm install @react-native-community/datetimepicker

yarn add @react-native-community/datetimepicker

yarn add -D @types/react-native-community__datetimepicker
